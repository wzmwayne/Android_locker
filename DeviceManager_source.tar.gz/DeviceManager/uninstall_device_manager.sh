#!/system/bin/sh

# 设备管理应用卸载脚本
# 用于完全卸载 DeviceManager 应用

PACKAGE_NAME="com.example.devicemanager"
SYSTEM_APP_DIR="/system/priv-app/DeviceManager"

echo "开始卸载 DeviceManager 应用..."

# 1. 去除设备管理器权限
echo "步骤 1/7: 去除设备管理器权限..."
dpm remove-active-admin $PACKAGE_NAME

# 2. 去除设备所有者权限（第一次）
echo "步骤 2/7: 去除设备所有者权限（第一次）..."
dpm remove-active-admin $PACKAGE_NAME

# 3. 去除设备所有者权限（第二次）
echo "步骤 3/7: 去除设备所有者权限（第二次）..."
dpm remove-active-admin $PACKAGE_NAME

# 4. 取消保活设置
echo "步骤 4/7: 取消保活设置..."
dumpsys deviceidle whitelist -$PACKAGE_NAME
settings put global always_finish_activities 1
settings put global low_power_mode_sticky 1

# 5. 设置为普通应用
echo "步骤 5/7: 设置为普通应用..."
pm unblock $PACKAGE_NAME
pm enable $PACKAGE_NAME

# 6. 从系统应用目录删除
echo "步骤 6/7: 从系统应用目录删除..."
if [ -f "$SYSTEM_APP_DIR/DeviceManager.apk" ]; then
    rm -f $SYSTEM_APP_DIR/DeviceManager.apk
fi
if [ -d "$SYSTEM_APP_DIR" ]; then
    rmdir $SYSTEM_APP_DIR
fi

# 7. 卸载应用
echo "步骤 7/7: 卸载应用..."
pm uninstall $PACKAGE_NAME

echo "脚本执行完成"
