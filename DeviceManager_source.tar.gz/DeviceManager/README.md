# 设备管理应用 (DeviceManager)

## 应用简介

这是一个合法的共享设备管理 Android 应用，用于设备租借、共享或个人设备隐私保护场景。

## 功能特性

### 1. 权限管理
- **设备管理员权限 (BIND_DEVICE_ADMIN)**：用于设备锁定和管理
- **悬浮窗权限 (SYSTEM_ALERT_WINDOW)**：用于显示锁定屏幕
- **自启动权限 (RECEIVE_BOOT_COMPLETED)**：设备启动后自动运行

### 2. 悬浮窗锁定屏幕
- 全屏显示，使用 TYPE_APPLICATION_OVERLAY
- 支持锁屏显示 (FLAG_SHOW_WHEN_LOCKED)
- 支持点亮屏幕 (FLAG_TURN_SCREEN_ON)
- **可触摸交互**：允许用户通过按钮输入密码

### 3. 密码验证系统
- 16 位数字密码输入
- SHA256 哈希值验证
- 配置文件：`assets/inf.sys`
  - 第一行：显示文字
  - 第二行：密码的 SHA256 哈希值（64 位小写十六进制）

### 4. 安全合规
- 包含醒目的安全声明
- 禁止自动配置或默认密码
- 所有密码哈希值必须由用户在 inf.sys 中指定

## 安装说明

### 1. 安装 APK
```bash
adb install app-debug.apk
```

### 2. 授予权限
首次启动应用后，需要授予以下权限：

1. **设备管理员权限**
   - 点击"检查并授予权限"按钮
   - 在弹出的系统页面中激活设备管理员

2. **悬浮窗权限**
   - 系统会自动跳转到设置页面
   - 允许应用在其他应用上层显示

3. **自启动权限**
   - 已在 AndroidManifest.xml 中声明
   - 部分设备可能需要在系统设置中手动开启

### 3. 配置密码
修改 `app/src/main/assets/inf.sys` 文件：

```
您的设备已被管理员锁定
807ae5f38db47bff8b09b37ad803cb10ef5147567a89a33a66bb3282df4ad966
```

**注意**：第二行必须是 64 位小写十六进制的 SHA256 哈希值。

### 4. 生成密码哈希
使用以下命令生成密码的 SHA256 哈希值：

```bash
echo -n "1234567890123456" | sha256sum | awk '{print $1}'
```

## 使用方法

1. 启动应用
2. 确保所有权限已授予
3. 点击"启动锁定服务"按钮
4. 悬浮窗将全屏显示
5. 输入 16 位数字密码
6. 点击"确认"按钮验证密码
7. 密码正确后，锁定屏幕将消失

## 安全声明

**您的设备已被管理员锁定，请联系管理员解锁。本应用仅供合法的设备管理（如租借，共享或合法的技术研究）或个人设备隐私保护，如您的设备被恶意锁定，请及时联系作者处理。作者邮箱：wzmwayne@hotmail.com**

## 技术实现

### 悬浮窗实现
- 使用 WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
- 设置 FLAG_SHOW_WHEN_LOCKED 和 FLAG_TURN_SCREEN_ON
- **未设置 FLAG_NOT_TOUCHABLE**，确保悬浮窗可触摸

### 密码验证
- 读取 assets/inf.sys 文件
- 验证文件格式（至少 2 行）
- 验证哈希值格式（64 位小写十六进制）
- 格式错误时显示 Toast 并自动退出

### 权限申请
- 符合 Android 8.0+ 规范
- 自动检测并引导用户授予权限
- 未授权时自动跳转系统设置页面

## 构建说明

### 环境要求
- Android SDK 34
- Gradle 8.10.2
- Java 17

### 构建命令
```bash
cd DeviceManager
./gradlew :app:assembleDebug
```

### 输出位置
`app/build/outputs/apk/debug/app-debug.apk`

## 注意事项

1. **仅用于合法用途**：本应用仅供合法的设备管理场景使用
2. **密码安全**：请妥善保管密码，不要使用默认密码
3. **配置文件**：修改 inf.sys 后需要重新构建应用
4. **权限要求**：必须授予所有权限才能正常使用
5. **设备兼容性**：建议使用 Android 7.0+ 设备

## 文件结构

```
DeviceManager/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── assets/
│   │       │   └── inf.sys          # 配置文件
│   │       ├── java/com/example/devicemanager/
│   │       │   ├── MainActivity.kt           # 主界面
│   │       │   ├── LockScreenService.kt      # 悬浮窗服务
│   │       │   ├── DeviceAdminReceiver.kt    # 设备管理员接收器
│   │       │   └── BootReceiver.kt           # 自启动接收器
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   ├── activity_main.xml     # 主界面布局
│   │       │   │   └── lock_screen.xml       # 锁定屏幕布局
│   │       │   ├── values/
│   │       │   │   └── strings.xml           # 字符串资源
│   │       │   └── xml/
│   │       │       └── device_admin_receiver.xml  # 设备管理员配置
│   │       └── AndroidManifest.xml
│   └── build.gradle.kts
└── README.md
```

## 许可证

本应用仅供学习和合法的设备管理用途使用。

## 联系方式

作者邮箱：wzmwayne@hotmail.com
