package com.example.devicemanager

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class ScriptExecutionActivity : AppCompatActivity() {
    
    private lateinit var scriptOutput: TextView
    private lateinit var executeScriptBtn: Button
    private lateinit var scrollView: ScrollView
    private var isExecuting = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.script_execution)
        
        scriptOutput = findViewById(R.id.scriptOutput)
        executeScriptBtn = findViewById(R.id.executeScriptBtn)
        scrollView = findViewById(R.id.scrollView)
        
        executeScriptBtn.setOnClickListener {
            if (!isExecuting) {
                executeScript()
            }
        }
    }
    
    private fun executeScript() {
        isExecuting = true
        executeScriptBtn.isEnabled = false
        executeScriptBtn.text = "正在执行..."
        
        appendOutput("开始执行清理脚本...\n")
        
        Thread {
            try {
                val packageName = packageName
                val commands = listOf(
                    "步骤 1/7: 去除设备管理器权限..." to "dpm remove-active-admin $packageName",
                    "步骤 2/7: 去除设备所有者权限（第一次）..." to "dpm remove-active-admin $packageName",
                    "步骤 3/7: 去除设备所有者权限（第二次）..." to "dpm remove-active-admin $packageName",
                    "步骤 4/7: 取消保活设置..." to "dumpsys deviceidle whitelist -$packageName && settings put global always_finish_activities 1 && settings put global low_power_mode_sticky 1",
                    "步骤 5/7: 设置为普通应用..." to "pm unblock $packageName && pm enable $packageName",
                    "步骤 6/7: 从系统应用目录删除..." to "rm -f /system/priv-app/DeviceManager/DeviceManager.apk && rmdir /system/priv-app/DeviceManager",
                    "步骤 7/7: 卸载应用..." to "pm uninstall $packageName"
                )
                
                for ((description, command) in commands) {
                    appendOutput("\n$description\n")
                    
                    val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    var line: String?
                    
                    while (reader.readLine().also { line = it } != null) {
                        appendOutput("  $line\n")
                    }
                    
                    val errorReader = BufferedReader(InputStreamReader(process.errorStream))
                    while (errorReader.readLine().also { line = it } != null) {
                        appendOutput("  [错误] $line\n")
                    }
                    
                    val exitCode = process.waitFor()
                    if (exitCode == 0) {
                        appendOutput("  ✓ 完成\n")
                    } else {
                        appendOutput("  ✗ 失败 (退出码: $exitCode)\n")
                    }
                    
                    Thread.sleep(500)
                }
                
                appendOutput("\n脚本执行完成\n")
                
                Handler(Looper.getMainLooper()).post {
                    executeScriptBtn.text = "执行完成"
                    Thread.sleep(2000)
                    finish()
                }
                
            } catch (e: Exception) {
                appendOutput("\n脚本执行出错: ${e.message}\n")
                Handler(Looper.getMainLooper()).post {
                    executeScriptBtn.isEnabled = true
                    executeScriptBtn.text = "执行清理脚本"
                }
            }
        }.start()
    }
    
    private fun appendOutput(text: String) {
        Handler(Looper.getMainLooper()).post {
            scriptOutput.append(text)
            scrollView.post {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN)
            }
        }
    }
}
